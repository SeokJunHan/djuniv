import React from 'react';

const Home = () => (
	<div>
		<p>
			EnactSample.
		</p>
	</div>
);

export default Home;
