import Changeable from '@enact/ui/Changeable';
import Group from '@enact/ui/Group';
import Item from '@enact/moonstone/Item';
import kind from '@enact/core/kind';
import Layout, {Cell} from '@enact/ui/Layout';
import MoonstoneDecorator from '@enact/moonstone/MoonstoneDecorator';
import PropTypes from 'prop-types';
import React from 'react';
import ScrollerComponent from '@enact/moonstone/Scroller';
import ViewManager from '@enact/ui/ViewManager';

import Button from '../views/Button';
import ContextualPopupDecorator from '../views/ContextualPopupDecorator';
import DayPicker from '../views/DayPicker';
import Dialog from '../views/Dialog';
import ExpandableItem from '../views/ExpandableItem';
import ExpandableList from '../views/ExpandableList';
import GroupItem from '../views/GroupItem';
import Input from '../views/Input';
import ItemView from '../views/Item';
import Lunacall from '../views/Lunacall';
import Notification from '../views/Notification';
import Panels from '../views/Panels';
import Picker from '../views/Picker';
import Popup from '../views/Popup';
import ProgressBar from '../views/ProgressBar';
import Scroller from '../views/Scroller';
import Slider from '../views/Slider';
import Spinner from '../views/Spinner';
import TooltipDecorator from '../views/TooltipDecorator';
import VideoPlayer from '../views/VideoPlayer';
import VirtualGridList from '../views/VirtualGridList';
import VirtualList from '../views/VirtualList';

import css from './App.less';
import Home from './Home';
import View from './View';

const views = [
	{title: '메인', view: Home},
	{title: '버튼생성', view: Button},
	{isAriaHidden: true, title: '유튜브 재생', view: VideoPlayer},
	{title: '영화 순위', view: VirtualGridList},
	{title: '소개분류', view: VirtualList}, //
	{title: 'ContextualPopupDecorator', view: ContextualPopupDecorator},
	{title: 'DayPicker', view: DayPicker},
	{title: 'Dialog', view: Dialog},
	{title: 'ExpandableItem', view: ExpandableItem},
	{title: 'ExpandableList', view: ExpandableList},
	{title: 'GroupItem', view: GroupItem},
	{title: 'Input', view: Input},
	{title: 'Item', view: ItemView},
	{title: 'Lunacall', view: Lunacall},
	{title: 'Notification', view: Notification},
	{isHeader: false, title: 'Panels', view: Panels},
	{title: 'Picker', view: Picker},
	{title: 'Popup', view: Popup},
	{title: 'ProgressBar', view: ProgressBar},
	{title: 'Scroller', view: Scroller},
	{title: 'Slider', view: Slider},
	{title: 'Spinner', view: Spinner},
	{title: 'TooltipDecorator', view: TooltipDecorator}
];

class AppBase extends React.Component {
	/*propTypes: {
		index: PropTypes.number,
		onChange: PropTypes.func
	}*/

	constructor () {
		super();

		this.state = {
			index: 0
		}
	}

	render () {
		// delete rest.onChange;

		const {onChange, ...rest} = this.props;

		const handleChange = ({selected}) => {
			this.setState({index: selected});
		};

		return (
			<Layout {...rest} className={css.app} style={{height: '100%'}}>
				<Cell component={ScrollerComponent} size="25%" >
					<Group childComponent={Item} itemProps={{className: css.navItem}} onSelect={handleChange} select={'radio'} selected={this.state.index}>
						{views.map((view) => view.title)}
					</Group>
				</Cell>
				<Cell component={ViewManager} index={this.state.index}>
					{views.map((view, i) => (
						<View {...view} movePage={() => {
							// onChange(3)
							this.setState({index: 3})
						}} key={i} />
					))}
				</Cell>
			</Layout>
		);
	}
}

const App = MoonstoneDecorator(AppBase);

export default App;
