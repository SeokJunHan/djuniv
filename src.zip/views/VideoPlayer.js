import Button from '@enact/moonstone/Button';
import IconButton from '@enact/moonstone/IconButton';
import React from 'react';
import ri from '@enact/ui/resolution';
import VideoPlayer, {MediaControls} from '@enact/moonstone/VideoPlayer';
import { VirtualGridList } from '@enact/moonstone/VirtualList/VirtualList';


const VideoPlayerView = (props) => (		
	<div style={{width: ri.scale(1280) + 'px', height: ri.scale(800) + 'px'}}>
		<iframe width="1280" height="720" src="https://www.youtube.com/embed/o15QWxrCHgU" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" >
		</iframe>
		<Button>영화순위로</Button>
		<Button onClick={() => {
			props.movePage();
		}}>홈</Button>
	</div>
		);

/*

class VideoPlayerView extends React.Component {
	handle = () => {
	
	}
	render () {
		return(		
	<div style={{width: ri.scale(1280) + 'px', height: ri.scale(800) + 'px'}}>
		<iframe width="1280" height="720" src="https://www.youtube.com/embed/o15QWxrCHgU" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" >
		</iframe>
		<Button>영화순위로</Button>
		<Button onClick={this.handle}>홈</Button>
	</div>
		);
	}
}
*/

export default VideoPlayerView;
